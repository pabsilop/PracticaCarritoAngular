export class Articulo{
    id:number;
    nombre:string;
    color:string;
    talla:string;
    cantidad:number;
    precioOriginal:number;
    precioRebajado:number;
    estaEnRebaja:boolean;

    constructor(id:number, nombre:string, color:string,talla:string,cantidad:number,precioOriginal:number,precioRebajado:number,estaEnRebaja:boolean){
        this.id = id;
        this.nombre = nombre;
        this.color = color;
        this.talla = talla;
        this.cantidad = cantidad;
        this.precioOriginal = precioOriginal;
        this.precioRebajado = precioRebajado;
        this.estaEnRebaja = estaEnRebaja;
    }
}
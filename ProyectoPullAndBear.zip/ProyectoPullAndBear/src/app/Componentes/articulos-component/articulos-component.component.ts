import { Component, OnChanges, OnInit } from '@angular/core';
import { Articulo } from '../../../models/Articulo';

@Component({
  selector: 'app-articulos-component',
  templateUrl: './articulos-component.component.html',
  styleUrls: ['./articulos-component.component.scss']
})
export class ArticulosComponentComponent implements OnInit,OnChanges {

  arrayArticulo:Articulo[] = [];
  precioTotal:number;

  constructor() { }

  ngOnInit(): void {

    this.arrayArticulo = [];
    this.precioTotal=0;
    this.arrayArticulo.push(new Articulo(1,'Pantalon vaquero','Negro','XL',1,20.50,18,true));
    this.arrayArticulo.push(new Articulo(2,'Camiseta Deporte','Rojo','L',1,15,10,true));
    this.arrayArticulo.push(new Articulo(3,'Vans','Negras','43',1,60.50,47,false));
    this.arrayArticulo.push(new Articulo(4,'Sudadera Element','Gris','XL',1,30,25,false));
    
    function totalCarrito(arrayArticulo:Articulo[]){
      let total:number = 0;
      for(let i:number = 0; i < arrayArticulo.length; i++){
          
        if (arrayArticulo[i].estaEnRebaja){
          total += (arrayArticulo[i].precioRebajado*arrayArticulo[i].cantidad);
        }else{
          total += (arrayArticulo[i].precioOriginal*arrayArticulo[i].cantidad);
        }

      }
      return total;
    }
    this.precioTotal = totalCarrito(this.arrayArticulo);

  }

ngOnChanges() {

  let total:number = 0;
      for(let i:number = 0; i < this.arrayArticulo.length; i++){
          
        if (this.arrayArticulo[i].estaEnRebaja){
          total += (this.arrayArticulo[i].precioRebajado*this.arrayArticulo[i].cantidad);
        }else{
          total += (this.arrayArticulo[i].precioOriginal*this.arrayArticulo[i].cantidad);
        }

      }
   this.precioTotal = Math.round(total);

  }

  eliminarArticulo(id:number){
    this.arrayArticulo.splice(id,1);
    let total:number = 0;
    for(let i:number = 0; i < this.arrayArticulo.length; i++){
        
      if (this.arrayArticulo[i].estaEnRebaja){
        total += (this.arrayArticulo[i].precioRebajado*this.arrayArticulo[i].cantidad);
      }else{
        total += (this.arrayArticulo[i].precioOriginal*this.arrayArticulo[i].cantidad);
      }

    }
 this.precioTotal = Math.round(total);
  }
}
